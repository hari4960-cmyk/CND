#include <assert.h>
#include <stdio.h>
#include "sequencer.h"
static uint16_t run(sequencer_t *s, int pressed, unsigned ms) {
    uint16_t v=s->mask;
    while(ms--) v=sequencer_tick_1ms(s,(uint8_t)pressed);
    return v;
}
int main(void) {
    sequencer_t s;
    sequencer_init(&s);
    assert(run(&s,0,1000)==0 && !s.running);
    puts("PASS power-on OFF");
    for (unsigned i=0;i<20;++i) run(&s,i&1,1);
    assert(!s.running);
    assert(run(&s,0,30)==0);
    puts("PASS contact bounce rejected");
    assert(run(&s,1,29)==0);
    assert(run(&s,1,1)==1 && s.running);
    puts("PASS first stable press starts D1");
    for(unsigned i=1;i<10;++i) assert(run(&s,1,100)==(1u<<i));
    assert(run(&s,1,100)==1);
    puts("PASS D1..D10 one-hot sequencing and wrap; held button does not retrigger");
    run(&s,0,30);
    assert(s.running);
    assert(run(&s,1,30)==0 && !s.running);
    assert(run(&s,1,1500)==0);
    puts("PASS second press OFF and held OFF");
    run(&s,0,30);assert(run(&s,1,30)==1 && s.running);
    puts("PASS next press restarts at D1");
    return 0;
}
