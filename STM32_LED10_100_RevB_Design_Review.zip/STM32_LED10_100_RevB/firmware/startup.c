#include <stdint.h>
extern uint32_t _estack, _sidata, _sdata, _edata, _sbss, _ebss;
extern int main(void);
void Default_Handler(void) { for (;;) {} }
void Reset_Handler(void) {
    uint32_t *src=&_sidata, *dst=&_sdata;
    while (dst < &_edata) *dst++=*src++;
    for (dst=&_sbss;dst < &_ebss;) *dst++=0;
    (void)main();
    for (;;) {}
}
__attribute__((section(".isr_vector"),used))
const void * const vectors[48] = {
    [0]=&_estack, [1]=Reset_Handler,
    [2]=Default_Handler, [3]=Default_Handler,
    [11]=Default_Handler, [14]=Default_Handler, [15]=Default_Handler,
    [16 ... 47]=Default_Handler
};
