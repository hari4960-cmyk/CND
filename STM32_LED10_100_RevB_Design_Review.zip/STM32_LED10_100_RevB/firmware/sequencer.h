#ifndef SEQUENCER_H
#define SEQUENCER_H
#include <stdint.h>
typedef struct {
    uint16_t mask, elapsed;
    uint8_t running, index, stable, candidate, debounce;
} sequencer_t;
void sequencer_init(sequencer_t *s);
uint16_t sequencer_tick_1ms(sequencer_t *s, uint8_t pressed);
#endif
