#include "sequencer.h"
void sequencer_init(sequencer_t *s) {
    s->mask=0; s->elapsed=0; s->running=0; s->index=0;
    s->stable=0; s->candidate=0; s->debounce=0;
}
uint16_t sequencer_tick_1ms(sequencer_t *s, uint8_t pressed) {
    pressed = !!pressed;
    if (pressed != s->candidate) { s->candidate=pressed; s->debounce=1; }
    else if (s->debounce < 30) { ++s->debounce; }
    if (s->debounce==30 && s->stable!=s->candidate) {
        s->stable=s->candidate;
        if (s->stable) {
            s->running ^= 1;
            s->index=0; s->elapsed=0;
            s->mask = s->running ? 1 : 0;
            return s->mask;
        }
    }
    if (s->running && ++s->elapsed >= 100) {
        s->elapsed=0;
        if (++s->index >= 10) s->index=0;
        s->mask=(uint16_t)(1u << s->index);
    }
    return s->mask;
}
