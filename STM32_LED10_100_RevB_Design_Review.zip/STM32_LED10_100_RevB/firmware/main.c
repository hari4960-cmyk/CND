/* STM32F030K6T6; HSI 8MHz; no HAL dependency; GPIO low-speed outputs.
 * D1..D8 = PA0..PA7, D9..D10 = PB0..PB1; MODE = PA8 active low.
 * PA13/PA14 retain SWD function; BOOT0 held low externally.
 */
#include <stdint.h>
#include "sequencer.h"
#define REG32(a) (*(volatile uint32_t *)(a))
#define RCC_CR REG32(0x40021000u)
#define RCC_CFGR REG32(0x40021004u)
#define RCC_AHBENR REG32(0x40021014u)
#define GPIOA 0x48000000u
#define GPIOB 0x48000400u
#define GPIOF 0x48001400u
#define MODER(b) REG32((b)+0x00u)
#define OTYPER(b) REG32((b)+0x04u)
#define OSPEEDR(b) REG32((b)+0x08u)
#define PUPDR(b) REG32((b)+0x0cu)
#define IDR(b) REG32((b)+0x10u)
#define BSRR(b) REG32((b)+0x18u)
#define SYST_CSR REG32(0xe000e010u)
#define SYST_RVR REG32(0xe000e014u)
#define SYST_CVR REG32(0xe000e018u)
static void leds(uint16_t bits) {
    uint32_t a=bits & 0xffu, b=(bits >> 8) & 3u;
    BSRR(GPIOA)=a | ((~a & 0xffu) << 16);
    BSRR(GPIOB)=b | ((~b & 3u) << 16);
}
int main(void) {
    RCC_CR |= 1u;                    /* enable HSI */
    while (!(RCC_CR & 2u)) {}
    RCC_CFGR &= ~3u;                 /* select HSI */
    while (RCC_CFGR & 12u) {}
    RCC_CFGR &= ~0x7f0u;             /* AHB/APB dividers = 1 */
    RCC_AHBENR |= (1u<<17) | (1u<<18) | (1u<<22);
    (void)RCC_AHBENR;                /* peripheral clock enable delay */
    leds(0);                        /* define output data before enabling outputs */
    OTYPER(GPIOA) &= ~0xffu; OTYPER(GPIOB) &= ~3u;
    OSPEEDR(GPIOA) &= ~0xffffu; OSPEEDR(GPIOB) &= ~15u;
    MODER(GPIOA) = (MODER(GPIOA) & ~0x3ffffu) | 0x5555u;
    /* Unused pins analog, keeping PA13/14 in their reset SWD mode. */
    MODER(GPIOA) |= (3u<<18) | (3u<<20) | (3u<<22) | (3u<<24) | (3u<<30);
    MODER(GPIOB) = 0xfffffff5u; /* PB0/1 outputs; all other PB pins analog */
    MODER(GPIOF) |= 15u;       /* PF0/PF1 analog; no external oscillator */
    PUPDR(GPIOF) &= ~15u;
    PUPDR(GPIOA) = (PUPDR(GPIOA) & ~0x3ffffu) | (1u<<16);
    PUPDR(GPIOB) &= ~15u;
    SYST_RVR=8000u-1u; SYST_CVR=0; SYST_CSR=5u; /* HCLK, polling, no interrupt */
    sequencer_t state; sequencer_init(&state);
    for (;;) {
        while (!(SYST_CSR & (1u<<16))) {}
        leds(sequencer_tick_1ms(&state, !(IDR(GPIOA) & (1u<<8))));
    }
}
