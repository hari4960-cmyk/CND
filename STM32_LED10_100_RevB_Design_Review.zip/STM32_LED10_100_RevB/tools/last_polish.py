from pathlib import Path
import pcbnew as p
path=Path(__file__).resolve().parents[1]/'STM32_LED10_100_RevB.kicad_pcb'
b=p.LoadBoard(str(path))
for f in b.GetFootprints():
 if f.GetReference()=='J1':f.Reference().SetPosition(p.VECTOR2I(p.FromMM(20),p.FromMM(53)))
p.SaveBoard(str(path),b)
