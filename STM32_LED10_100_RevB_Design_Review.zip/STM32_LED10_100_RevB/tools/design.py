import os,json,uuid,re,copy,math
from pathlib import Path
import pcbnew as p
import sexpr as sx
sx.Path=Path;sx.json=json;sx.re=re;sx.copy=copy
from sexpr import symbol,tag,child,val,dump
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT);NAME='STM32_LED10_100_RevB'
def uid(s=None):return str(uuid.uuid5(uuid.NAMESPACE_URL,NAME+'/'+s)) if s else str(uuid.uuid4())
comps=[]
def comp(ref,lib,name,value,fp,nets,sch,pcb,rot=0):
 comps.append(dict(ref=ref,lib=lib,name=name,value=value,fp=fp,nets={str(k):v for k,v in nets.items()},sch=sch,pcb=pcb,rot=rot,uuid=uid(ref)))
R='Resistor_SMD:R_0805_2012Metric';C='Capacitor_SMD:C_0805_2012Metric';LED='LED_SMD:LED_0805_2012Metric'
mp={1:'+3V3',17:'+3V3',5:'+3V3',16:'GND',32:'GND',4:'NRST',31:'BOOT0',18:'BUTTON',23:'SWDIO',24:'SWCLK'}
for i,pin in enumerate([6,7,8,9,10,11,12,13,14,15]):mp[pin]='LED'+str(i+1)
comp('U1','MCU_ST_STM32F0','STM32F030K6Tx','STM32F030K6T6','Package_QFP:LQFP-32_7x7mm_P0.8mm',mp,(90,155),(50,50))
for i in range(10):
 n=i+1;x=15+(i%5)*17.5;y=16 if i<5 else 84;ry=y+5 if i<5 else y-5;sxx=200+(i%5)*40;sy=55 if i<5 else 125
 comp('R'+str(n),'Device','R','1k',R,{1:'LED'+str(n),2:'A'+str(n)},(sxx,sy),(x,ry),90)
 comp('D'+str(n),'Device','LED','RED',LED,{1:'GND',2:'A'+str(n)},(sxx,sy+17),(x,y),90)
comp('J1','Connector_Generic','Conn_01x02','+5V INPUT','TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal',{1:'+5V_IN',2:'GND'},(30,50),(10,50))
comp('D11','Device','D_Schottky','SS14','Diode_SMD:D_SMA',{1:'VIN_PROT',2:'+5V_IN'},(65,50),(22,50),0)
comp('U2','Regulator_Linear','AP2112K-3.3','AP2112K-3.3TRG1','Package_TO_SOT_SMD:SOT-23-5',{1:'VIN_PROT',2:'GND',3:'VIN_PROT',5:'+3V3'},(110,50),(29,50))
for ref,value,sch,pcb,rot in [('C1','100n/16V',(30,240),(42,46.5),180),('C2','100n/16V',(50,240),(58,53),0),('C3','100n/16V',(70,240),(42,51),180),('C4','1u/10V',(90,240),(38,51),180),('C5','4.7u/10V',(110,240),(50,37),0)]:comp(ref,'Device','C',value,C,{1:'+3V3',2:'GND'},sch,pcb,rot)
comp('R11','Device','R','10k',R,{1:'+3V3',2:'NRST'},(35,125),(41,41),0)
comp('C6','Device','C','100n/16V',C,{1:'NRST',2:'GND'},(35,150),(37,44),180)
comp('R12','Device','R','10k',R,{1:'BOOT0',2:'GND'},(35,180),(50,42),0)
comp('J2','Connector_Generic','Conn_01x05','SWD 3V3','Connector_PinHeader_2.54mm:PinHeader_1x05_P2.54mm_Vertical',{1:'+3V3',2:'SWDIO',3:'GND',4:'SWCLK',5:'NRST'},(150,175),(65,40))
comp('SW1','Switch','SW_Push','RUN / OFF','Button_Switch_SMD:SW_SPST_TL3305A',{1:'BUTTON',2:'GND'},(280,210),(85,50))
comp('R13','Device','R','10k',R,{1:'+3V3',2:'BUTTON'},(240,210),(81,44))
comp('C7','Device','C','100n/16V',C,{1:'BUTTON',2:'GND'},(320,210),(77,50))
comp('C8','Device','C','2.2u/10V',C,{1:'VIN_PROT',2:'GND'},(90,85),(25,44))
comp('C9','Device','C','2.2u/10V',C,{1:'+3V3',2:'GND'},(130,85),(33,44))
comp('C10','Device','C','10u/10V',C,{1:'+3V3',2:'GND'},(155,85),(30,55))
for i,(net,pos,sch) in enumerate([('+5V_IN',(18,42),(40,85)),('+3V3',(35,58),(175,50)),('GND',(41,58),(175,85))]):
 comp('TP'+str(i+1),'Connector','TestPoint',net,'TestPoint:TestPoint_Pad_D2.0mm',{1:net},sch,pos)
rootid=uid('root');syms={};lines=[f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {rootid}) (paper "A3") (title_block (title "5V STM32 LED10 SEQUENCER") (rev "B") (company "100 x 100 mm / 2-layer / FR-4")) (lib_symbols']
for c in comps:
 key=c['lib']+':'+c['name']
 if key not in syms:
  a=symbol(c['lib'],c['name']);a[1]=json.dumps(key);syms[key]=a;lines.append(dump(a))
f=symbol('power','PWR_FLAG');f[1]='"power:PWR_FLAG"';syms['power:PWR_FLAG']=f;lines.append(dump(f));lines.append(')')
def put(c):
 key=c['lib']+':'+c['name'];x,y=[round(v/1.27)*1.27 for v in c['sch']];a=syms[key];pins=[k for u in a if tag(u)=='symbol' for k in u if tag(k)=='pin'];ref=c['ref'];xx=x-4;yy=y-5;vx=x+5;vy=y+5
 if ref=='U1':xx=x-15;yy=y-27;vx=x+35;vy=y-27
 if ref=='U2':xx=x-5;yy=y-8;vx=x+2;vy=y-11
 if ref.startswith('#'):xx=x-4;yy=y-5;vx=x+4;vy=y+2
 hide=' (hide yes)' if ref.startswith('#') else ''
 valuehide=' (hide yes)' if ref.startswith('TP') else hide
 props=f'(property "Reference" "{ref}" (at {xx} {yy} 0) (effects (font (size 1.1 1.1)){hide})) (property "Value" "{c["value"]}" (at {vx} {vy} 0) (effects (font (size 1 1)){valuehide})) (property "Footprint" "{c["fp"]}" (at {x} {y} 0) (effects (font (size 1 1)) (hide yes)))'
 ids=' '.join(f'(pin {child(k,"number")[1]} (uuid {uid(ref+"/pin/"+val(child(k,"number")[1]))}))' for k in pins)
 lines.append(f'(symbol (lib_id "{key}") (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {c["uuid"]}) {props} {ids} (instances (project "{NAME}" (path "/{rootid}" (reference "{ref}") (unit 1)))))')
 used=set()
 for k in pins:
  num=val(child(k,'number')[1]);
  if ref=='U1' and num in ['1','17','5']:continue
  at=child(k,'at');px=round(x+float(at[1]),5);py=round(y-float(at[2]),5)
  if (px,py) in used:continue
  used.add((px,py));net=c['nets'].get(num)
  if net is None:lines.append(f'(no_connect (at {px} {py}) (uuid {uid(ref+"/nc/"+num)}))');continue
  angle=int(at[3]);dx,dy={0:(-5.08,0),180:(5.08,0),90:(0,5.08),270:(0,-5.08)}[angle];ex=round(px+dx,5);ey=round(py+dy,5)
  lines.append(f'(wire (pts (xy {px} {py}) (xy {ex} {ey})) (stroke (width 0) (type default)) (uuid {uid(ref+"/wire/"+num)}))')
  lines.append(f'(label "{net}" (at {ex} {ey} 0) (effects (font (size 1 1)) (justify left bottom)) (uuid {uid(ref+"/label/"+num)}))')
 # Shared VDD/VDDA supply bus keeps closely spaced power-pin labels readable.
 if ref=='U1':
  bus_y=round(y-33.02,5);pin_y=round(y-27.94,5)
  for dx in [-2.54,0,2.54]:
   lines.append(f'(wire (pts (xy {x+dx} {pin_y}) (xy {x+dx} {bus_y})) (stroke (width 0) (type default)) (uuid {uid("VDDbranch"+str(dx))}))')
  for dx1,dx2 in [(-2.54,0),(0,2.54)]:
   lines.append(f'(wire (pts (xy {x+dx1} {bus_y}) (xy {x+dx2} {bus_y})) (stroke (width 0) (type default)) (uuid {uid("VDDbus"+str(dx1))}))')
  lines.append(f'(wire (pts (xy {x} {bus_y}) (xy {x} {bus_y-5.08})) (stroke (width 0) (type default)) (uuid {uid("VDDfeed")}))')
  lines.append(f'(junction (at {x} {bus_y}) (diameter 0) (color 0 0 0 0) (uuid {uid("VDDjunction")}))')
  lines.append(f'(label "+3V3" (at {x} {bus_y-5.08} 0) (effects (font (size 1 1)) (justify left bottom)) (uuid {uid("VDDlabel")}))')

for c in comps:put(c)
for i,net in enumerate(['+5V_IN','VIN_PROT','GND']):put(dict(lib='power',name='PWR_FLAG',ref='#FLG0'+str(i+1),value='PWR_FLAG',fp='',sch=(145+i*25,255),nets={'1':net},uuid=uid('FLAG'+str(i))))
for text,x,y in [('POWER: regulated +5V +/-5%; SS14 reverse-polarity protection; 3.3V LDO',20,20),('D1-D10: 0805 red LEDs; 1k series resistors; active HIGH',190,30),('MCU: internal HSI 8MHz, BOOT0 pull-down, NRST RC, SWD programming',20,105),('SW1: first press = repeating D1 -> D10, 100ms/step; next press = ALL OFF',210,185),('Power-on state = ALL OFF. Hardware RC + firmware debounce. No external crystal.',210,240),('C1/C2: VDD decoupling. C3/C4: VDDA decoupling. C5: local bulk.',20,222),('J2 pins: 1=3V3 Vref, 2=SWDIO, 3=GND, 4=SWCLK, 5=NRST',210,253)]:
 lines.append(f'(text "{text}" (at {x} {y} 0) (effects (font (size 1.2 1.2)) (justify left)) (uuid {uid(text)}))')
lines.append(')');Path(NAME+'.kicad_sch').write_text('\n'.join(lines))
libs=sorted(set(c['lib'] for c in comps)|{'power'})
Path('sym-lib-table').write_text('(sym_lib_table (version 7) '+''.join(f'(lib (name "{l}") (type "KiCad") (uri "${{KICAD9_SYMBOL_DIR}}/{l}.kicad_sym") (options "") (descr ""))' for l in libs)+')')
if os.environ.get('SCHEMATIC_ONLY'):raise SystemExit(0)
b=p.BOARD();b.SetCopperLayerCount(2);nets={}
for n in sorted(set(n for c in comps for n in c['nets'].values())):
 q=p.NETINFO_ITEM(b,'/'+n);b.Add(q);nets[n]=q
def v(x,y):return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
for c in comps:
 lib,fp=c['fp'].split(':');f=p.FootprintLoad('/usr/share/kicad/footprints/'+lib+'.pretty',fp)
 if f is None:raise RuntimeError(c['fp'])
 f.SetReference(c['ref']);f.SetValue(c['value']);f.SetFPID(p.LIB_ID(lib,fp));f.SetPosition(v(*c['pcb']));f.SetOrientationDegrees(c['rot']);f.SetPath(p.KIID_PATH('/'+rootid+'/'+c['uuid']));b.Add(f)
 for pad in f.Pads():
  num=pad.GetNumber()
  if num in c['nets']:pad.SetNet(nets[c['nets'][num]])
 f.Value().SetVisible(False);f.Reference().SetTextSize(v(1,1));f.Reference().SetTextThickness(p.FromMM(.15));f.Reference().SetTextAngle(p.EDA_ANGLE(0,p.DEGREES_T));x,y=c['pcb']
 pos=(x,y-2.5)
 if c['ref'].startswith('R'):pos=(x+2.5,y)
 if c['ref']=='U1':pos=(x,y)
 if c['ref']=='U2':pos=(x,y-3)
 if c['ref']=='J1':pos=(x+2.5,y-6)
 if c['ref']=='J2':pos=(x+3,y+5)
 if c['ref']=='SW1':pos=(x,y+4)
 f.Reference().SetPosition(v(*pos))
for a,z in [((0,0),(100,0)),((100,0),(100,100)),((100,100),(0,100)),((0,100),(0,0))]:
 s=p.PCB_SHAPE();s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart(v(*a));s.SetEnd(v(*z));s.SetLayer(p.Edge_Cuts);s.SetWidth(p.FromMM(.05));b.Add(s)
for i,(x,y) in enumerate([(5,5),(95,5),(5,95),(95,95)]):
 f=p.FootprintLoad('/usr/share/kicad/footprints/MountingHole.pretty','MountingHole_3.2mm_M3');f.SetReference('H'+str(i+1));f.SetBoardOnly(True);f.SetPosition(v(x,y));f.Reference().SetVisible(False);f.Value().SetVisible(False);b.Add(f)
for text,x,y,size in [('STM32 LED10 SEQUENCER',50,6,1.5),('5V INPUT / 3.3V LOGIC / REV B',50,93,1.2),('+5V',10,41,1.1),('GND',10,61,1.1),('SWD 3.3V',65,35,1),('RUN / OFF',85,59,1.2),('SWD: 1VREF 2DIO 3GND 4CLK 5RST',53,64,.9),('100 x 100 mm / 2 LAYERS',50,97,1)]:
 t=p.PCB_TEXT(b);t.SetText(text);t.SetPosition(v(x,y));t.SetTextSize(v(size,size));t.SetTextThickness(p.FromMM(.18));t.SetLayer(p.F_SilkS);b.Add(t)
tb=b.GetTitleBlock();tb.SetTitle('STM32 LED10 5V SEQUENCER');tb.SetRevision('B');tb.SetComment(0,'100 x 100mm, 2 layers, 1.6mm FR-4');b.SetTitleBlock(tb)
p.SaveBoard(NAME+'.kicad_pcb',b);p.SaveBoard('tools/placed.kicad_pcb',b);Path('tools/components.json').write_text(json.dumps(comps,indent=2));print('Generated',len(comps),'components',len(nets),'nets')
