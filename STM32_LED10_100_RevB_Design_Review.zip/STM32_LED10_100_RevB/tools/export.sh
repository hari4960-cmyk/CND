#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-/tmp/stm32-kicad-config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/tmp/stm32-kicad-cache}"
export XDG_DATA_HOME="${XDG_DATA_HOME:-/tmp/stm32-kicad-data}"
mkdir -p "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$XDG_DATA_HOME" fabrication preview reports
kicad-cli sch erc STM32_LED10_100_RevB.kicad_sch --exit-code-violations -o reports/erc.rpt
kicad-cli pcb drc STM32_LED10_100_RevB.kicad_pcb --schematic-parity --exit-code-violations -o reports/drc.rpt
kicad-cli pcb drc STM32_LED10_100_RevB.kicad_pcb --schematic-parity --format json --exit-code-violations -o reports/drc.json
kicad-cli sch export netlist STM32_LED10_100_RevB.kicad_sch -o reports/LED10.net
kicad-cli sch export pdf STM32_LED10_100_RevB.kicad_sch -o preview/Schematic.pdf
kicad-cli pcb export gerbers STM32_LED10_100_RevB.kicad_pcb -o fabrication/ -l F.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,B.SilkS,Edge.Cuts --subtract-soldermask
kicad-cli pcb export drill STM32_LED10_100_RevB.kicad_pcb -o fabrication/ --excellon-separate-th --generate-map --map-format pdf
kicad-cli pcb export svg STM32_LED10_100_RevB.kicad_pcb -o preview/PCB_top.svg -l F.Cu,F.SilkS,Edge.Cuts --mode-single --page-size-mode 2 --exclude-drawing-sheet
kicad-cli pcb export svg STM32_LED10_100_RevB.kicad_pcb -o preview/PCB_bottom.svg -l B.Cu,B.SilkS,Edge.Cuts --mode-single --page-size-mode 2 --exclude-drawing-sheet --mirror
kicad-cli pcb export pos STM32_LED10_100_RevB.kicad_pcb -o fabrication/STM32_LED10_100_RevB_CPL.csv --format csv --units mm --side front --smd-only
