# Sources and verification scope

Retrieved 2026-11-19.

- KiCad installed symbol libraries: MCU_ST_STM32F0.kicad_sym / STM32F030K6Tx; Regulator_Linear.kicad_sym / AP2112K-3.3.
- https://raw.githubusercontent.com/STMicroelectronics/cmsis-device-f0/master/Include/stm32f030x6.h — downloaded; GPIO/RCC base addresses and clock bit positions checked.
- https://raw.githubusercontent.com/STMicroelectronics/cmsis-device-f0/master/Source/Templates/system_stm32f0xx.c — downloaded; HSI_VALUE/SystemCoreClock=8MHz checked.
- https://raw.githubusercontent.com/STMicroelectronics/cmsis-device-f0/master/LICENSE.md — downloaded with sources.
- https://www.st.com/resource/en/datasheet/stm32f030k6.pdf — BLOCKED, proxy CONNECT HTTP403; not read.
- https://www.diodes.com/assets/Datasheets/AP2112.pdf — BLOCKED, proxy CONNECT HTTP403; not read.

Official PDF electrical/package review remains pending. No specific PDF page/revision claimed verified.
