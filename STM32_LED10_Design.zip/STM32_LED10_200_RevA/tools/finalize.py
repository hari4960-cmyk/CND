import os,math,json,re,copy
from pathlib import Path
import pcbnew as p
import sexpr as sx
sx.Path=Path;sx.re=re;sx.json=json;sx.copy=copy
from sexpr import parse,tag,child,val
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT);NAME='STM32_LED10_200_RevA';b=p.LoadBoard(NAME+'.kicad_pcb')
def v(x,y):return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
for f in b.GetFootprints():
 ref=f.GetReference()
 if ref=='TP1':
  old=p.VECTOR2I(f.GetPosition());new=v(37,97)
  for t in b.GetTracks():
   if t.GetClass()!='PCB_TRACK':continue
   if t.GetStart()==old:t.SetStart(new)
   if t.GetEnd()==old:t.SetEnd(new)
  f.SetPosition(new);f.Reference().SetPosition(v(37,94.5))
 if ref.startswith('TP'):f.SetExcludedFromBOM(False)
 if ref in ['R11','R12','R13']:f.Reference().SetPosition(f.GetPosition()+v(0,-2.5))
# Match KiCad's explicit single-pad unconnected nets rather than leaving NC pads on net 0.
netlist=parse(Path('reports/design.net').read_text());netsec=child(netlist,'nets');fmap={f.GetReference():f for f in b.GetFootprints()}
for n in netsec[1:]:
 name=val(child(n,'name')[1]);nodes=[a for a in n if tag(a)=='node']
 if not name.startswith('unconnected-'):continue
 if b.FindNet(name).GetNetCode() < 0 if b.FindNet(name) else True:
  net=p.NETINFO_ITEM(b,name);b.Add(net)
 else:net=b.FindNet(name)
 for item in nodes:
  ref=val(child(item,'ref')[1]);pin=val(child(item,'pin')[1])
  for pad in fmap[ref].Pads():
   if pad.GetNumber()==pin:pad.SetNet(net)
for z in b.Zones():z.SetIslandRemovalMode(p.ISLAND_REMOVAL_MODE_ALWAYS)
p.ZONE_FILLER(b).Fill(b.Zones())
# Near-pad GND stitching connects local islands and provides short decoupling returns.
zs=list(b.Zones());top=next(z for z in zs if z.GetLayer()==p.F_Cu);bot=next(z for z in zs if z.GetLayer()==p.B_Cu);a=top.GetFilledPolysList(p.F_Cu);d=bot.GetFilledPolysList(p.B_Cu);gnd=b.FindNet('/GND').GetNetCode()
pads=[q for f in b.GetFootprints() for q in f.Pads()];vias=[t for t in b.GetTracks() if t.GetClass()=='PCB_VIA'];added=[]
def safe(x,y):
 for q in pads:
  px=p.ToMM(q.GetPosition().x);py=p.ToMM(q.GetPosition().y);w=p.ToMM(q.GetSize().x)/2;h=p.ToMM(q.GetSize().y)/2
  if round(q.GetOrientationDegrees())%180:w,h=h,w
  if abs(x-px)<w+.35 and abs(y-py)<h+.35:return False
 for q in vias:
  px=p.ToMM(q.GetPosition().x);py=p.ToMM(q.GetPosition().y)
  if math.hypot(x-px,y-py)<.8:return False
 return True
for q in pads:
 if q.GetNetCode()!=gnd or q.GetAttribute()!=p.PAD_ATTRIB_SMD:continue
 pos=q.GetPosition();indices=[i for i in range(a.OutlineCount()) if a.Contains(pos,i)]
 if not indices:continue
 px=p.ToMM(pos.x);py=p.ToMM(pos.y);found=False
 for radius in [1.25,1.5,1.75,2,2.5,3]:
  for j in range(16):
   x=round(px+radius*math.cos(j*math.pi/8),1);y=round(py+radius*math.sin(j*math.pi/8),1)
   if not safe(x,y):continue
   if all(any(a.Contains(v(x+.4*math.cos(t),y+.4*math.sin(t)),i) for i in indices) and d.Contains(v(x+.4*math.cos(t),y+.4*math.sin(t))) for t in [k*math.pi/8 for k in range(16)]):
    via=p.PCB_VIA(b);via.SetPosition(v(x,y));via.SetLayerPair(p.F_Cu,p.B_Cu);via.SetWidth(p.F_Cu,p.FromMM(.6));via.SetDrill(p.FromMM(.3));via.SetViaType(p.VIATYPE_THROUGH);via.SetNetCode(gnd);b.Add(via);vias.append(via);added.append((x,y));found=True;break
  if found:break
p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(NAME+'.kicad_pcb',b);print('Added near-pad GND stitches:',len(added))
s=Path(NAME+'.kicad_pcb').read_text()
if '(stackup' not in s:
 s=s.replace('(setup','''(setup
 (stackup
  (layer "F.SilkS" (type "Top Silk Screen"))
  (layer "F.Mask" (type "Top Solder Mask") (thickness 0.01) (epsilon_r 3.3) (loss_tangent 0))
  (layer "F.Cu" (type "copper") (thickness 0.035))
  (layer "dielectric 1" (type "core") (thickness 1.53) (material "FR4") (epsilon_r 4.3) (loss_tangent 0.02))
  (layer "B.Cu" (type "copper") (thickness 0.035))
  (layer "B.Mask" (type "Bottom Solder Mask") (thickness 0.01) (epsilon_r 3.3) (loss_tangent 0))
  (layer "B.SilkS" (type "Bottom Silk Screen"))
  (copper_finish "ENIG") (dielectric_constraints no)
 )''',1);Path(NAME+'.kicad_pcb').write_text(s)
x=json.loads(Path(NAME+'.kicad_pro').read_text());rules=x['board']['design_settings']['rules'];rules.update(min_clearance=.2,min_track_width=.2,min_via_diameter=.6,min_through_hole_diameter=.3,min_copper_edge_clearance=.5,min_hole_to_hole=.25,min_silk_clearance=.1)
x['net_settings']['classes'][0].update(clearance=.2,track_width=.25,via_diameter=.6,via_drill=.3)
x['board']['design_settings']['track_widths']=[0,.25,.5];x['board']['design_settings']['via_dimensions']=[{'diameter':.6,'drill':.3}]
Path(NAME+'.kicad_pro').write_text(json.dumps(x,indent=2))
