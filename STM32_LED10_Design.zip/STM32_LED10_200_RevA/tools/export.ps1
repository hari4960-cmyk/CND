param([string]$KiCadCli = 'kicad-cli')
$ErrorActionPreference = 'Stop'
Push-Location (Split-Path $PSScriptRoot -Parent)
function Invoke-KiCad {
    & $KiCadCli @args
    if ($LASTEXITCODE -ne 0) { throw "KiCad command failed with exit code $LASTEXITCODE" }
}
try {
    New-Item -ItemType Directory -Force -Path reports,preview,fabrication | Out-Null
    $base = 'STM32_LED10_200_RevA'
    Invoke-KiCad sch erc "$base.kicad_sch" --exit-code-violations -o reports/erc.rpt
    Invoke-KiCad pcb drc "$base.kicad_pcb" --schematic-parity --exit-code-violations -o reports/drc.rpt
    Invoke-KiCad pcb drc "$base.kicad_pcb" --schematic-parity --format json --exit-code-violations -o reports/drc.json
    Invoke-KiCad sch export netlist "$base.kicad_sch" -o reports/LED10.net
    Invoke-KiCad sch export pdf "$base.kicad_sch" -o preview/Schematic.pdf
    Invoke-KiCad pcb export gerbers "$base.kicad_pcb" -o fabrication/ -l 'F.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,B.SilkS,Edge.Cuts' --subtract-soldermask
    Invoke-KiCad pcb export drill "$base.kicad_pcb" -o fabrication/ --excellon-separate-th --generate-map --map-format pdf
    Invoke-KiCad pcb export pos "$base.kicad_pcb" -o "fabrication/${base}_CPL.csv" --format csv --units mm --side front --smd-only
} finally { Pop-Location }
