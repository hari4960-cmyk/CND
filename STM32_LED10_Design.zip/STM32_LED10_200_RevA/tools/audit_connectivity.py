import json,re,copy,math
from pathlib import Path
import pcbnew as p
import sexpr as sx
sx.Path=Path;sx.re=re;sx.json=json;sx.copy=copy
from sexpr import parse,tag,child,val
r=Path(__file__).resolve().parents[1];netlist=parse((r/'reports/LED10.net').read_text())
netmap={};nodes={}
for n in child(netlist,'nets')[1:]:
 name=val(child(n,'name')[1]);pins={(val(child(a,'ref')[1]),val(child(a,'pin')[1])) for a in n if tag(a)=='node'};nodes[name]=pins
 for node in pins:netmap[node]=name
checks=[]
def same(title,pins,expected):
 values={netmap[tuple(q)] for q in pins};assert values=={expected},(title,values);checks.append('PASS '+title)
same('Input connector polarity',[('J1','1'),('D11','2'),('TP1','1')],'/+5V_IN')
same('Protected input and LDO enable',[('D11','1'),('U2','1'),('U2','3'),('C8','1')],'/VIN_PROT')
same('MCU VDD pins 1/17 and VDDA pin 5',[('U2','5'),('U1','1'),('U1','17'),('U1','5')],'/+3V3')
same('MCU VSS pins 16 and 32',[('U1','16'),('U1','32'),('J1','2')],'/GND')
for i,pin in enumerate([6,7,8,9,10,11,12,13,14,15],1):
 same('LED'+str(i)+' GPIO mapping',[('U1',str(pin)),('R'+str(i),'1')],'/LED'+str(i))
 same('LED'+str(i)+' anode series resistor',[('R'+str(i),'2'),('D'+str(i),'2')],'/A'+str(i))
 assert netmap[('D'+str(i),'1')]=='/GND'
same('Button PA8 and debounce network',[('U1','18'),('SW1','1'),('R13','2'),('C7','1')],'/BUTTON')
same('SWDIO PA13',[('U1','23'),('J2','2')],'/SWDIO')
same('SWCLK PA14',[('U1','24'),('J2','4')],'/SWCLK')
same('NRST pullup, RC and programming',[('U1','4'),('R11','2'),('C6','1'),('J2','5')],'/NRST')
same('BOOT0 ground pull-down',[('U1','31'),('R12','1')],'/BOOT0');assert netmap[('R12','2')]=='/GND'
for ref in ['C1','C2','C3','C4','C5','C9','C10']:same(ref+' supply/ground',[ (ref,'1'),('U2','5') ],'/+3V3');assert netmap[(ref,'2')]=='/GND'
b=p.LoadBoard(str(r/'STM32_LED10_200_RevA.kicad_pcb'));assert b.GetCopperLayerCount()==2
checks.append('PASS two copper layers')
edgepoints=[t.GetStart() for t in b.GetDrawings() if t.GetLayer()==p.Edge_Cuts];xs=[p.ToMM(q.x) for q in edgepoints];ys=[p.ToMM(q.y) for q in edgepoints];assert max(xs)-min(xs)==200 and max(ys)-min(ys)==200;checks.append('PASS 200 x 200 mm outline centerline')
(r/'reports/connectivity_audit.txt').write_text('\n'.join(checks)+f'\n{len(checks)} connectivity/geometry assertions passed.\n')
print('\n'.join(checks[-4:]));print(len(checks),'assertions passed')
